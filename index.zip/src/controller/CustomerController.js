import { Sequelize, Op } from 'sequelize';
import {
    UserCustomer,
    CustomerPackage,
    VendorPackage,
    VendorPackageDefaultItem,
    VendorPackageMenuItems,
    CustomerOrder,
    VendorMenuItems,
    CustomerOrderItem,
    VendorCustomerLink,
    VendorSettings,
    CustomerDeliveryAddress,
    CitiesAll
} from '../config/Models/relations.js';
import crypto from 'crypto';
import { loggedInUser } from '../middleware/Auth.js';
import Helper from '../utils/Helper.js';
import twilio from 'twilio';
import { sendEmail } from '../utils/email.js'

export const savePackages = async (req, res) => {
    try {
        const packagesData = req.body;
        const loggedInUserId = loggedInUser(req);

        // Loop through the data and associate each package with the vendor
        for (const packageData of packagesData) {
            const packageInstance = await CustomerPackage.create({
                user_id: loggedInUserId,
                package_id: packageData.id,
                payment_status: 0,
                frequency: packageData.frequency,
                user_package_name: packageData.packagename,
                quantity: packageData.quantity,
                created_date: packageData.date,
                start_date: new Date(),
                end_date: new Date(),
            });
        }
        return res.status(200).json({ success: true });
    } catch (error) {
        console.error('Error saving data:', error);
    }
}

export const checkExistingUser = async (req, res) => {
    try {
        const { phone } = req.body;
        const loggedInUserId = loggedInUser(req);
        const existingUser = await UserCustomer.findOne({
            where: {
                phone,
                vendor_id: loggedInUserId,
            },
            include: [
                {
                    model: VendorCustomerLink,
                },
                {
                    model: CustomerPackage,
                }
            ],
        });

        if (!existingUser) {
            return res.status(200).json({ status: false, message: 'Phone Number does not exist.' });
        } else {
            return res.status(200).json({ status: true, data: existingUser, message: 'Phone number exists.' });
        }
    } catch (error) {
        console.error('Error fetching customers:', error.stack);
        return res.status(500).json({ status: 'failed', error: 'Internal Server Error' });
    }
};

export const saveCustomer = async (req, res) => {
    const userData = req.body;
    const loggedInUserId = loggedInUser(req);
    let createdUser;
    try {
        if (!userData.id) {
            createdUser = await UserCustomer.create({
                //   id: userData.id,
                first_name: userData.first_name,
                last_name: userData.last_name,
                //    password: userData.password,
                email: userData.email,
                phone: '1' + userData.phone,
                address_1: userData.address,
                address_2: userData.address_2,
                postal_code: userData.postal_code,
                created_date: new Date(),
                status: 0,
                city_id: 1,
                last_login: new Date(),
                last_order: 1,
                vendor_id: loggedInUserId,
            });
        } else {
            createdUser = await UserCustomer.findOne({
                where: { id: userData.id }
            })
        }
        if (!userData.id) {
            const packageDetails = await VendorPackage.findOne({
                where: { id: userData.package }
            });
            if (packageDetails) {
                const customerPackage = await CustomerPackage.create({
                    user_id: createdUser.id,
                    package_id: packageDetails.id,
                    payment_status: 0,
                    frequency: 'daily',
                    user_package_name: '',
                    quantity: '1',
                    created_date: userData.start_date,
                    start_date: new Date(),
                    end_date: new Date(),
                });
            }
        }
        const VendorCustomer = await VendorCustomerLink.create({
            vendor_id: loggedInUserId,
            customer_id: createdUser.id,
            package_id: userData.package,
            delivery_instructions: userData.delivery_instruction,
            status: 1,
            created_at: new Date(),
        });

        const accountSid = process.env.TWILIO_ACCOUNT_SID;
        const authToken = process.env.TWILIO_AUTH_TOKEN;
        const client = twilio(accountSid, authToken);

        let pin = Helper.generateRandomPin(8);
        while (!(await isCodeUnique(pin))) {
            pin = Helper.generateRandomPin(8);
        }

        await createdUser.update({
            verification_code: pin,
        });

        client.messages.create({
            // body: `click the following link to create a new account http://localhost:5173/customer-onboard/${pin}.`,
            body: `click the following link to create a new account https://menuscribe.com/customer-onboard/${pin}.`,
            from: '+16474928950',
            to: '+1' + userData.phone
            //   to: '+923459637337'
        }).then(message => console.log(message.sid));

        // const to = userData.email;
        // const subject = 'Test Email';
        // const text = `Create the following link to create a new account http://localhost:5173/customer-onboard/${pin}.`;

        // sendEmail(to, subject, text);

        res.json({ success: true, message: 'Data inserted successfully', data: createdUser });
    } catch (error) {
        console.error('Error inserting data:', error);
        res.status(500).json({ error: 'Internal Server Error', error_detail: error });
    }
};

async function isCodeUnique(pin) {
    const existingUser = await UserCustomer.findOne({
        where: {
            verification_code: pin,
        },
    });
    return !existingUser;
}

export const getCustomer = async (req, res) => {
    const Id = req.params.id;
    try {
        const result = await UserCustomer.findOne({
            where: { id: Id },
        });
        if (result.status === 2) {
            res.status(200).json({ success: true, data: { id: result.id, phone: result.phone } });
        } else {
            res.status(200).json({ success: true, data: result });
        }
    } catch (error) {
        console.log('Error fetching customer: ' + error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

export const getCustomerByVc = async (req, res) => {
    const Id = req.params.id;
    try {
        const results = await UserCustomer.findOne({
            where: { verification_code: Id },
        });
        res.status(200).json({ success: true, data: results });
    } catch (error) {
        console.log('Error fetching customer: ' + error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

function hashPassword(password) {
    return crypto.createHash('md5').update(password).digest('hex');
}

export const updateCustomerPassword = async (req, res) => {
    try {
        const customerData = req.body;
        // Find the existing item
        const existingCustomer = await UserCustomer.findByPk(customerData.id);

        if (!existingCustomer) {
            return res.status(404).json({ error: 'Item not found' });
        }
        let pin = Helper.generateRandomPin(4);
        while (!(await isPinUnique(pin))) {
            pin = Helper.generateRandomPin(4);
        }
        // Update the existing item's properties
        existingCustomer.password = hashPassword(customerData.password);
        existingCustomer.status = 2;
        existingCustomer.verification_pin = pin;
        // Save the updated item
        await existingCustomer.save();

        client.messages.create({
            // body: `click the following link to create a new account http://localhost:5173/customer-onboard/${pin}.`,
            body: `Use the pin for verification ${pin}.`,
            from: '+16474928950',
            to: '+1' + existingCustomer.phone
            //   to: '+923459637337'
        }).then(message => console.log(message.sid));

        // const to = existingCustomer.email;
        // const subject = 'Test Email';
        // const text = `Use the pin for verification ${pin}.`;

        // sendEmail(to, subject, text);

        res.status(200).json({ success: true, data: { id: existingCustomer.id } });

    } catch (error) {
        console.error('Error updating user:', error);
        return res.status(500).json({ error: 'Internal server error' });
    }
};

async function isPinUnique(pin) {
    const existingUser = await UserCustomer.findOne({
        where: {
            verification_code: pin,
            status: {
                [Sequelize.Op.ne]: 1,
            },
        },
    });
    return !existingUser;
}

export const checkVerificationPin = async (req, res) => {
    try {
        const customerData = req.body;
        // Find the existing item
        const pinVerify = await UserCustomer.findOne({
            where: {
                verification_pin: customerData.pin,
                id: customerData.id
            },
        });

        if (!pinVerify) {
            return res.status(404).json({ error: 'Item not found' });
        }
        res.status(200).json({ success: true, data: { id: pinVerify.id } });

    } catch (error) {
        console.error('Error updating user:', error);
        return res.status(500).json({ error: 'Internal server error' });
    }
};
export const updateCustomer = async (req, res) => {
    try {
        const customerData = req.body;
        // Find the existing item
        const existingCustomer = await UserCustomer.findByPk(customerData.id);

        if (!existingCustomer) {
            return res.status(404).json({ error: 'Item not found' });
        }
        // Update the existing item's properties
        existingCustomer.first_name = customerData.first_name;
        existingCustomer.last_name = customerData.last_name;
        existingCustomer.email = customerData.email;
        existingCustomer.phone = customerData.phone;
        existingCustomer.address_1 = customerData.address;
        existingCustomer.delivery_instruction = customerData.delivery_instruction;
        existingCustomer.postal_code = customerData.postal_code;
        existingCustomer.city_id = customerData.city;
        existingCustomer.status = 1;

        // Save the updated item
        await existingCustomer.save();

        res.status(200).json({ success: true, data: existingCustomer.id });

    } catch (error) {
        console.error('Error updating user:', error);
        return res.status(500).json({ error: 'Internal server error' });
    }
};

export const getUserPackages = async (req, res) => {
    const { ids } = req.body;
    try {
        const results = await CustomerPackage.findAll({
            include: [
                {
                    model: VendorPackage,
                },
            ],
            where: { package_id: ids },
        });
        res.status(200).json({ success: true, data: results });
    } catch (error) {
        console.log('Error fetching customer: ' + error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

export const getCustomerPackages = async (req, res) => {
    //const { id } = req.body;
    const id = req.params.id;
    try {
        const customer = await UserCustomer.findOne({
            where: { id: id }
        });

        let vendorSetting, CustomerAddress;
        if (customer) {
            vendorSetting = await VendorSettings.findOne({
                where: { id: customer.vendor_id }
            });

            CustomerAddress = await CustomerDeliveryAddress.findAll({
                where: { customer_id: id },
                include: {
                    model: CitiesAll,
                }
            });
        }

        const results = await CustomerPackage.findAll({
            include: [
                {
                    model: VendorPackage,
                    include: [
                        {
                            model: VendorPackageDefaultItem,
                            include: [
                                {
                                    model: VendorPackageMenuItems,
                                }
                            ],
                        }
                    ]
                },
                {
                    model: UserCustomer,
                },
            ],
            where: { user_id: id, payment_status: 1 },
        });

        res.status(200).json({ success: true, data: { results, vendorSetting, CustomerAddress } });
    } catch (error) {
        console.log('Error fetching customer: ' + error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

export const saveCustomerOrder = async (req, res) => {
    const { ids } = req.body;
    try {
        const loggedInUserId = loggedInUser(req);
        const results = await CustomerPackage.findAll({
            include: [
                {
                    model: VendorPackage,
                    include: [
                        {
                            model: VendorPackageDefaultItem,
                            include: [
                                {
                                    model: VendorMenuItems,
                                },
                                {
                                    model: VendorPackageMenuItems,
                                }
                            ],
                        }
                    ]
                },
            ],
            where: { package_id: ids },
        });

        results.forEach(async (customerPackage) => {

            let arr = [];
            let daysCount;
            let totalAmount;
            if (customerPackage.VendorPackage.sun === 1) {
                arr.push('sunday')
            }
            if (customerPackage.VendorPackage.mon === 1) {
                arr.push('monday')
            }
            if (customerPackage.VendorPackage.tue === 1) {
                arr.push('tuesday')
            }
            if (customerPackage.VendorPackage.wed === 1) {
                arr.push('wednesday')
            }
            if (customerPackage.VendorPackage.thu === 1) {
                arr.push('thursday')
            }
            if (customerPackage.VendorPackage.fri === 1) {
                arr.push('friday')
            }
            if (customerPackage.VendorPackage.sat === 1) {
                arr.push('saturday')
            }

            if (customerPackage.frequency === 'daily') {
                daysCount = 1;
            } else if (customerPackage.frequency === 'weekly') {
                daysCount = 5;
            } else if (customerPackage.frequency === 'monthly') {
                daysCount = 20;
            }
            if (customerPackage.frequency === 'daily') {
                totalAmount = customerPackage.VendorPackage.price_daily;
            } else if (customerPackage.frequency === 'weekly') {
                totalAmount = customerPackage.VendorPackage.price_weekly;
            } else if (customerPackage.frequency === 'monthly') {
                totalAmount = customerPackage.VendorPackage.price_monthly;
            }

            const nextDays = Helper.getNextDatesOfWeek(arr);
            //console.log(nextDays)

            nextDays.forEach(async (days) => {
                let deliveryTime = `${days.Date}T${customerPackage.VendorPackage.delivery_schedule_start}`;
                const createdOrder = await CustomerOrder.create({
                    user_id: loggedInUserId,
                    vendor_id: customerPackage.VendorPackage.vendor_id,
                    package_id: customerPackage.VendorPackage.id,
                    created_date: new Date(),
                    is_ready: 0,
                    is_delivered: 0,
                    subtotal: 0,
                    tax: 0,
                    total: totalAmount,
                    delivery_img: '',
                    delivered_time: new Date(deliveryTime),
                });

                customerPackage.VendorPackage.VendorPackageDefaultItems.forEach(async (ditem) => {
                    const createdOrderItem = await CustomerOrderItem.create({
                        order_id: createdOrder.id,
                        item_id: ditem.VendorMenuItem.id,
                    });
                })

            });


        });
        res.status(200).json({ success: true, data: results });
    } catch (error) {
        console.log('Error fetching customer: ' + error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

export const cancelCustomerOrder = async (req, res) => {
    const customerData = req.body;
    try {

        const customer = await CustomerPackage.findOne({
            where: { user_id: customerData.customer_id, package_id: customerData.package_id },
        });

        if (!customer) {
            return res.status(404).json({ error: 'Customer not found' });
        }
        // Update the existing item's properties
        customer.payment_status = 0;
        await customer.save();

        res.status(200).json({ success: true, data: customer.id });
    } catch (error) {
        console.log('Error fetching customer: ' + error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

export const getCustomerAddress = async (req, res) => {
    try {
        const { id } = req.params;
        const results = await CustomerDeliveryAddress.findOne({
            where: { id: id },
        });
        res.status(200).json({ success: true, data: results });
    } catch (error) {
        console.log('Error fetching address: ' + error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

export const updateCustomerAddress = async (req, res) => {
    try {
        let address;
        const addressData = req.body;
        if (addressData.id === 0 || addressData.id === undefined) {
            address = await CustomerDeliveryAddress.create({
                address: addressData.address,
                customer_id: addressData.customer_id,
                city_id: addressData.city_id,
                postal: addressData.postal,
                delivery_instructions: addressData.delivery_instructions,
                status: 1,
            });
        } else {
            address = await CustomerDeliveryAddress.findByPk(addressData.id);
            if (!address) {
                return res.status(404).json({ error: 'Item not found' });
            }
            address.address = addressData.address;
            address.city_id = addressData.city_id;
            address.postal = addressData.postal;
            address.delivery_instructions =  addressData.delivery_instructions,
            await address.save();
        }
        res.status(200).json({ success: true, data: address.id });
    } catch (error) {
        console.log('Error saving address: ' + error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

export const deleteCustomerAddress = async (req, res) => {
    const addressId = req.params.id;
    try {
      const results = await CustomerDeliveryAddress.destroy({
        where: { id: addressId },
      });
      res.status(200).json({ success: true, data: results });
    } catch (error) {
      console.log('Error deleting address: ' + error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  }